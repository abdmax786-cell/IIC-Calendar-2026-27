# IIC Event Tracker (Netlify)

Password: IIC@113
To change it: Netlify > Site configuration > Environment variables > add IIC_PASSWORD, then redeploy.

## Deploy
Netlify has to install one dependency (@netlify/blobs) while building, so use one of these two ways.
Plain drag-and-drop of the folder does not install it.

A. GitHub: push this folder to a GitHub repo, then Netlify > Add new site > Import from Git. Leave the build settings as they are.
B. CLI: run `npm i -g netlify-cli`, then in this folder `npm install`, `netlify login`, `netlify init`, `netlify deploy --prod`.

## How it works
- public/index.html is the website.
- netlify/functions/api.mjs checks the password and saves every edit in Netlify Blobs, so all faculty see the same data.
- netlify/functions/base.mjs holds the event list from your Excel file.
